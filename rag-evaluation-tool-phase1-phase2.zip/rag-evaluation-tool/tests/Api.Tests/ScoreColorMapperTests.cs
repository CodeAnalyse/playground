using Api.Mappings;
using Xunit;

namespace Api.Tests;

public class ScoreColorMapperTests
{
    [Theory]
    [InlineData(0, "Red")]
    [InlineData(0.1, "Orange")]
    [InlineData(0.3, "Yellow")]
    [InlineData(0.6, "Light Green")]
    [InlineData(0.9, "Green")]
    public void MapsScoreToColor(double score, string color)
    {
        Assert.Equal(color, ScoreColorMapper.GetColor(score));
    }
}
