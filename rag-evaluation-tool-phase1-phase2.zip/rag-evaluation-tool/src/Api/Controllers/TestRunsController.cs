using Api.Dtos;
using Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

[ApiController]
[Route("api/test-runs")]
public class TestRunsController : ControllerBase
{
    private readonly ITestRunService _service;
    public TestRunsController(ITestRunService service) => _service = service;

    [HttpPost]
    public async Task<IActionResult> Save([FromBody] SaveTestRunRequest request, CancellationToken cancellationToken)
    {
        await _service.SaveAsync(request, cancellationToken);
        return CreatedAtAction(nameof(GetByTestId), new { testId = request.TestId }, request);
    }

    [HttpGet("dates")]
    public async Task<ActionResult<IEnumerable<DateTime>>> GetDates(CancellationToken cancellationToken)
        => Ok(await _service.GetAvailableDatesAsync(cancellationToken));

    [HttpGet]
    public async Task<ActionResult<IEnumerable<TestRunSummaryDto>>> GetByDate([FromQuery] DateTime date, CancellationToken cancellationToken)
        => Ok(await _service.GetSummariesByDateAsync(date, cancellationToken));

    [HttpGet("{testId}")]
    public async Task<ActionResult<SaveTestRunRequest>> GetByTestId(string testId, CancellationToken cancellationToken)
        => await _service.GetByTestIdAsync(testId, cancellationToken) is { } run ? Ok(run) : NotFound();
}
