using Api.Dtos;
using Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

[ApiController]
[Route("api/predefined-questions")]
public class PredefinedQuestionsController : ControllerBase
{
    private readonly IPredefinedQuestionService _service;
    public PredefinedQuestionsController(IPredefinedQuestionService service) => _service = service;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<PredefinedQuestionViewModel>>> GetByChannel([FromQuery] string channelId, CancellationToken cancellationToken)
        => Ok(await _service.GetByChannelIdAsync(channelId, cancellationToken));

    [HttpGet("{id}")]
    public async Task<ActionResult<PredefinedQuestionViewModel>> GetById(string id, CancellationToken cancellationToken)
        => await _service.GetByIdAsync(id, cancellationToken) is { } item ? Ok(item) : NotFound();

    [HttpPost]
    public async Task<ActionResult<PredefinedQuestionViewModel>> Create([FromBody] CreatePredefinedQuestionRequest request, CancellationToken cancellationToken)
    {
        var created = await _service.CreateAsync(request, cancellationToken);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult<PredefinedQuestionViewModel>> Update(string id, [FromBody] CreatePredefinedQuestionRequest request, CancellationToken cancellationToken)
        => await _service.UpdateAsync(id, request, cancellationToken) is { } updated ? Ok(updated) : NotFound();

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id, CancellationToken cancellationToken)
        => await _service.DeleteAsync(id, cancellationToken) ? NoContent() : NotFound();
}
