using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

[ApiController]
[Route("channel")]
public class ChannelsController : ControllerBase
{
    [HttpPost("list")]
    public IActionResult List() => Ok(new[]
    {
        new { id = "OATI", name = "OATI", dataSource = new[] { "energy_public" }, environment = (string?)null, envColor = (string?)null, type = "General", isDefault = true }
    });
}
