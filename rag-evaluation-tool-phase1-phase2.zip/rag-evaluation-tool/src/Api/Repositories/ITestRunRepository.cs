using Api.Models;

namespace Api.Repositories;

public interface ITestRunRepository
{
    Task CreateAsync(TestRunModel model, CancellationToken cancellationToken = default);
    Task<List<DateTime>> GetAvailableDatesAsync(CancellationToken cancellationToken = default);
    Task<List<TestRunModel>> GetByDateAsync(DateTime date, CancellationToken cancellationToken = default);
    Task<TestRunModel?> GetByTestIdAsync(string testId, CancellationToken cancellationToken = default);
}
