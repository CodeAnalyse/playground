using Api.Models;
using Infrastructure.Mongo;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;

namespace Api.Repositories;

public class PredefinedQuestionRepository : IPredefinedQuestionRepository
{
    private readonly IMongoCollection<PredefinedQuestionModel> _collection;

    public PredefinedQuestionRepository(IMongoContext context)
    {
        _collection = context.Database.GetCollection<PredefinedQuestionModel>("PredefinedQuestions");
    }

    public Task<List<PredefinedQuestionModel>> GetByChannelIdAsync(string channelId, CancellationToken cancellationToken = default) =>
        _collection.Find(x => x.Channel.Id == channelId).ToListAsync(cancellationToken);

    public Task<PredefinedQuestionModel?> GetByIdAsync(string id, CancellationToken cancellationToken = default) =>
        _collection.Find(x => x.Id == id).FirstOrDefaultAsync(cancellationToken);

    public Task CreateAsync(PredefinedQuestionModel model, CancellationToken cancellationToken = default) =>
        _collection.InsertOneAsync(model, cancellationToken: cancellationToken);

    public Task UpdateAsync(PredefinedQuestionModel model, CancellationToken cancellationToken = default) =>
        _collection.ReplaceOneAsync(x => x.Id == model.Id, model, cancellationToken: cancellationToken);

    public Task DeleteAsync(string id, CancellationToken cancellationToken = default) =>
        _collection.DeleteOneAsync(x => x.Id == id, cancellationToken);
}
