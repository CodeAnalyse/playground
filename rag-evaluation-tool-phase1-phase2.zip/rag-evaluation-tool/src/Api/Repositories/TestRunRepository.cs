using Api.Models;
using Infrastructure.Mongo;
using MongoDB.Driver;

namespace Api.Repositories;

public class TestRunRepository : ITestRunRepository
{
    private readonly IMongoCollection<TestRunModel> _collection;

    public TestRunRepository(IMongoContext context)
    {
        _collection = context.Database.GetCollection<TestRunModel>("TestRunLogs");
    }

    public Task CreateAsync(TestRunModel model, CancellationToken cancellationToken = default) =>
        _collection.InsertOneAsync(model, cancellationToken: cancellationToken);

    public async Task<List<DateTime>> GetAvailableDatesAsync(CancellationToken cancellationToken = default)
    {
        var docs = await _collection.Find(_ => true).Project(x => new { x.RunDate }).ToListAsync(cancellationToken);
        return docs.Select(x => x.RunDate.Date).Distinct().OrderByDescending(x => x).ToList();
    }

    public Task<List<TestRunModel>> GetByDateAsync(DateTime date, CancellationToken cancellationToken = default)
    {
        var start = date.Date;
        var end = start.AddDays(1);
        return _collection.Find(x => x.RunDate >= start && x.RunDate < end).ToListAsync(cancellationToken);
    }

    public Task<TestRunModel?> GetByTestIdAsync(string testId, CancellationToken cancellationToken = default) =>
        _collection.Find(x => x.TestId == testId).FirstOrDefaultAsync(cancellationToken);
}
