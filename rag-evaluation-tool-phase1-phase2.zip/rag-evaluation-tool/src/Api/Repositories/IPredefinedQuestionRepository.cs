using Api.Models;

namespace Api.Repositories;

public interface IPredefinedQuestionRepository
{
    Task<List<PredefinedQuestionModel>> GetByChannelIdAsync(string channelId, CancellationToken cancellationToken = default);
    Task<PredefinedQuestionModel?> GetByIdAsync(string id, CancellationToken cancellationToken = default);
    Task CreateAsync(PredefinedQuestionModel model, CancellationToken cancellationToken = default);
    Task UpdateAsync(PredefinedQuestionModel model, CancellationToken cancellationToken = default);
    Task DeleteAsync(string id, CancellationToken cancellationToken = default);
}
