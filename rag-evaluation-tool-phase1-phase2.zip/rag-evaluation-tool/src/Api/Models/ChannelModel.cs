namespace Api.Models;

public class ChannelModel
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string DataSource { get; set; } = string.Empty;
    public string Product { get; set; } = string.Empty;
}
