namespace Api.Models;

public class TestRunModel
{
    public string Id { get; set; } = string.Empty;
    public string TestId { get; set; } = string.Empty;
    public DateTime RunDate { get; set; }
    public ChannelModel Channel { get; set; } = new();
    public string? TriggeredBy { get; set; }
    public int TotalQuestions { get; set; }
    public int CompletedQuestions { get; set; }
    public int FailedQuestions { get; set; }
    public List<TestRunResultModel> Results { get; set; } = [];
}

public class TestRunResultModel
{
    public string QuestionId { get; set; } = string.Empty;
    public int Ticket { get; set; }
    public string RelatedQuestion { get; set; } = string.Empty;
    public string ExpectedResponse { get; set; } = string.Empty;
    public string AgentResponse { get; set; } = string.Empty;
    public double SemanticSimilarityScore { get; set; }
    public string ScoreColor { get; set; } = string.Empty;
    public string ConversationId { get; set; } = string.Empty;
    public string? PromptId { get; set; }
    public string Status { get; set; } = string.Empty;
    public string? Error { get; set; }
    public DateTime StartedAt { get; set; }
    public DateTime CompletedAt { get; set; }
}
