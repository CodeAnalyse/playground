using Api.Models;

namespace Api.Dtos;

public class SaveTestRunRequest
{
    public string TestId { get; set; } = string.Empty;
    public DateTime RunDate { get; set; }
    public ChannelModel Channel { get; set; } = new();
    public string? TriggeredBy { get; set; }
    public int TotalQuestions { get; set; }
    public int CompletedQuestions { get; set; }
    public int FailedQuestions { get; set; }
    public List<TestRunResultModel> Results { get; set; } = [];
}

public class TestRunSummaryDto
{
    public string TestId { get; set; } = string.Empty;
    public DateTime RunDate { get; set; }
    public string ChannelName { get; set; } = string.Empty;
    public int TotalQuestions { get; set; }
    public int CompletedQuestions { get; set; }
    public int FailedQuestions { get; set; }
}
