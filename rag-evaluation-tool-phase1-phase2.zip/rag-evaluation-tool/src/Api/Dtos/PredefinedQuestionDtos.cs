using Api.Models;

namespace Api.Dtos;

public class PredefinedQuestionViewModel
{
    public string Id { get; set; } = string.Empty;
    public int Ticket { get; set; }
    public string RelatedQuestion { get; set; } = string.Empty;
    public string ExpectedResponse { get; set; } = string.Empty;
    public ChannelModel Channel { get; set; } = new();
}

public class CreatePredefinedQuestionRequest
{
    public int Ticket { get; set; }
    public string RelatedQuestion { get; set; } = string.Empty;
    public string ExpectedResponse { get; set; } = string.Empty;
    public ChannelModel Channel { get; set; } = new();
}
