namespace Api.Mappings;

public static class ScoreColorMapper
{
    public static string GetColor(double score) => score switch
    {
        <= 0 => "Red",
        <= 0.25 => "Orange",
        <= 0.5 => "Yellow",
        <= 0.75 => "Light Green",
        _ => "Green"
    };
}
