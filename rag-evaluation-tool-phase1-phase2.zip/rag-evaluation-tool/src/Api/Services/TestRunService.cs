using Api.Dtos;
using Api.Models;
using Api.Repositories;

namespace Api.Services;

public class TestRunService : ITestRunService
{
    private readonly ITestRunRepository _repository;
    public TestRunService(ITestRunRepository repository) => _repository = repository;

    public Task SaveAsync(SaveTestRunRequest request, CancellationToken cancellationToken = default) =>
        _repository.CreateAsync(new TestRunModel
        {
            Id = Guid.NewGuid().ToString("N"),
            TestId = request.TestId,
            RunDate = request.RunDate,
            Channel = request.Channel,
            TriggeredBy = request.TriggeredBy,
            TotalQuestions = request.TotalQuestions,
            CompletedQuestions = request.CompletedQuestions,
            FailedQuestions = request.FailedQuestions,
            Results = request.Results
        }, cancellationToken);

    public async Task<List<TestRunSummaryDto>> GetSummariesByDateAsync(DateTime date, CancellationToken cancellationToken = default) =>
        (await _repository.GetByDateAsync(date, cancellationToken))
            .Select(x => new TestRunSummaryDto { TestId = x.TestId, RunDate = x.RunDate, ChannelName = x.Channel.Name, TotalQuestions = x.TotalQuestions, CompletedQuestions = x.CompletedQuestions, FailedQuestions = x.FailedQuestions })
            .ToList();

    public Task<List<DateTime>> GetAvailableDatesAsync(CancellationToken cancellationToken = default) => _repository.GetAvailableDatesAsync(cancellationToken);

    public async Task<SaveTestRunRequest?> GetByTestIdAsync(string testId, CancellationToken cancellationToken = default)
    {
        var run = await _repository.GetByTestIdAsync(testId, cancellationToken);
        if (run is null) return null;
        return new SaveTestRunRequest { TestId = run.TestId, RunDate = run.RunDate, Channel = run.Channel, TriggeredBy = run.TriggeredBy, TotalQuestions = run.TotalQuestions, CompletedQuestions = run.CompletedQuestions, FailedQuestions = run.FailedQuestions, Results = run.Results };
    }
}
