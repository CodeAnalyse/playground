using Api.Dtos;
using Api.Models;
using Api.Repositories;

namespace Api.Services;

public class PredefinedQuestionService : IPredefinedQuestionService
{
    private readonly IPredefinedQuestionRepository _repository;
    public PredefinedQuestionService(IPredefinedQuestionRepository repository) => _repository = repository;

    public async Task<List<PredefinedQuestionViewModel>> GetByChannelIdAsync(string channelId, CancellationToken cancellationToken = default) =>
        (await _repository.GetByChannelIdAsync(channelId, cancellationToken)).Select(ToVm).ToList();

    public async Task<PredefinedQuestionViewModel?> GetByIdAsync(string id, CancellationToken cancellationToken = default)
    {
        var model = await _repository.GetByIdAsync(id, cancellationToken);
        return model is null ? null : ToVm(model);
    }

    public async Task<PredefinedQuestionViewModel> CreateAsync(CreatePredefinedQuestionRequest request, CancellationToken cancellationToken = default)
    {
        var model = new PredefinedQuestionModel { Id = Guid.NewGuid().ToString("N"), Ticket = request.Ticket, RelatedQuestion = request.RelatedQuestion.Trim(), ExpectedResponse = request.ExpectedResponse.Trim(), Channel = request.Channel };
        await _repository.CreateAsync(model, cancellationToken);
        return ToVm(model);
    }

    public async Task<PredefinedQuestionViewModel?> UpdateAsync(string id, CreatePredefinedQuestionRequest request, CancellationToken cancellationToken = default)
    {
        var existing = await _repository.GetByIdAsync(id, cancellationToken);
        if (existing is null) return null;
        existing.Ticket = request.Ticket;
        existing.RelatedQuestion = request.RelatedQuestion.Trim();
        existing.ExpectedResponse = request.ExpectedResponse.Trim();
        existing.Channel = request.Channel;
        await _repository.UpdateAsync(existing, cancellationToken);
        return ToVm(existing);
    }

    public async Task<bool> DeleteAsync(string id, CancellationToken cancellationToken = default)
    {
        var existing = await _repository.GetByIdAsync(id, cancellationToken);
        if (existing is null) return false;
        await _repository.DeleteAsync(id, cancellationToken);
        return true;
    }

    private static PredefinedQuestionViewModel ToVm(PredefinedQuestionModel m) => new() { Id = m.Id, Ticket = m.Ticket, RelatedQuestion = m.RelatedQuestion, ExpectedResponse = m.ExpectedResponse, Channel = m.Channel };
}
