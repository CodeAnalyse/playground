using Api.Dtos;

namespace Api.Services;

public interface ITestRunService
{
    Task SaveAsync(SaveTestRunRequest request, CancellationToken cancellationToken = default);
    Task<List<TestRunSummaryDto>> GetSummariesByDateAsync(DateTime date, CancellationToken cancellationToken = default);
    Task<List<DateTime>> GetAvailableDatesAsync(CancellationToken cancellationToken = default);
    Task<SaveTestRunRequest?> GetByTestIdAsync(string testId, CancellationToken cancellationToken = default);
}
