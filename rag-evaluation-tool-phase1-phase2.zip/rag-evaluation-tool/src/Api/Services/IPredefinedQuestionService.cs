using Api.Dtos;

namespace Api.Services;

public interface IPredefinedQuestionService
{
    Task<List<PredefinedQuestionViewModel>> GetByChannelIdAsync(string channelId, CancellationToken cancellationToken = default);
    Task<PredefinedQuestionViewModel?> GetByIdAsync(string id, CancellationToken cancellationToken = default);
    Task<PredefinedQuestionViewModel> CreateAsync(CreatePredefinedQuestionRequest request, CancellationToken cancellationToken = default);
    Task<PredefinedQuestionViewModel?> UpdateAsync(string id, CreatePredefinedQuestionRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(string id, CancellationToken cancellationToken = default);
}
