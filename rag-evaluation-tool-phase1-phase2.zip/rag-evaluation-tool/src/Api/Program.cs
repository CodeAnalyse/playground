using Api.Repositories;
using Api.Services;
using Infrastructure.Mongo;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

builder.Host.UseSerilog((ctx, lc) => lc.ReadFrom.Configuration(ctx.Configuration).WriteTo.Console());

builder.Services.Configure<MongoSettings>(builder.Configuration.GetSection(MongoSettings.SectionName));
builder.Services.AddSingleton<IMongoContext, MongoContext>();
builder.Services.AddScoped<IPredefinedQuestionRepository, PredefinedQuestionRepository>();
builder.Services.AddScoped<ITestRunRepository, TestRunRepository>();
builder.Services.AddScoped<IPredefinedQuestionService, PredefinedQuestionService>();
builder.Services.AddScoped<ITestRunService, TestRunService>();
builder.Services.AddControllers().AddJsonOptions(o => o.JsonSerializerOptions.PropertyNamingPolicy = null);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSerilogRequestLogging();
app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.Run();

public partial class Program { }
