using MongoDB.Driver;

namespace Infrastructure.Mongo;

public interface IMongoContext
{
    IMongoDatabase Database { get; }
}
