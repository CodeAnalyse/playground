using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace Infrastructure.Mongo;

public class MongoContext : IMongoContext
{
    public IMongoDatabase Database { get; }

    public MongoContext(IOptions<MongoSettings> options)
    {
        var settings = options.Value;
        var client = new MongoClient(settings.ConnectionString);
        Database = client.GetDatabase(settings.DatabaseName);
    }
}
