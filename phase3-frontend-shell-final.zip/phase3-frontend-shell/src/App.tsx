import { useMemo, useState } from 'react';
import { AppShell, Badge, Button, Container, Group, Paper, Stack, Text, Title, Select, TextInput } from '@mantine/core';
import { ChannelSelector } from './components/ChannelSelector';
import { QuestionList } from './components/QuestionList';
import { TestRunner } from './components/TestRunner';
import { ResultsColumn } from './components/ResultsColumn';
import { mockChannels, mockQuestions } from './mockData';
import type { QuestionRow } from './types';
import { ThemeToggle } from './components/ThemeToggle';

function scoreColor(score: number) {
  if (score <= 0) return 'Red';
  if (score <= 0.25) return 'Orange';
  if (score <= 0.5) return 'Yellow';
  if (score <= 0.75) return 'Light Green';
  return 'Green';
}

export default function App({ colorScheme, setColorScheme }: { colorScheme: 'light' | 'dark'; setColorScheme: (v: 'light' | 'dark') => void; }) {
  const [channelId, setChannelId] = useState<string | null>('OATI');
  const [running, setRunning] = useState(false);
  const [historyDate, setHistoryDate] = useState('2026-07-08');
  const [historyTestId, setHistoryTestId] = useState<string | null>(null);
  const [historyMode, setHistoryMode] = useState(false);
  const [testId, setTestId] = useState('TEST-20260708-001');
  const [runStatus, setRunStatus] = useState('Ready');
  const [rows, setRows] = useState<QuestionRow[]>(mockQuestions['OATI']);

  const selectedChannel = useMemo(() => mockChannels.find(c => c.id === channelId) ?? null, [channelId]);

  const toggleRow = (id: string) => setRows(prev => prev.map(r => r.id === id ? { ...r, selected: !r.selected } : r));
  const toggleAll = (checked: boolean) => setRows(prev => prev.map(r => ({ ...r, selected: checked })));

  const switchChannel = (id: string | null) => {
    setChannelId(id);
    setRows(mockQuestions[id ?? 'OATI'] ?? []);
  };

  const loadHistory = () => {
    setHistoryMode(true);
    setRunStatus(`Loaded ${historyTestId ?? 'Test Id'} for ${historyDate}`);
    const loaded = mockQuestions[channelId ?? 'OATI'] ?? [];
    setRows(loaded.map((r, i) => ({ ...r, status: 'done', score: Number((0.4 + i * 0.2).toFixed(2)), scoreColor: i === 0 ? 'Yellow' : 'Green', agentResponse: `Historical response ${r.ticket ?? i + 1}` })));
  };

  const run = async (all: boolean) => {
    setRunning(true);
    setHistoryMode(false);
    setRunStatus('Running...');
    const selected = (mockQuestions[channelId ?? 'OATI'] ?? []).filter(r => all || r.selected);
    const testRunId = `TEST-${new Date().toISOString().slice(0,10).replaceAll('-','')}-001`;
    setTestId(testRunId);
    for (let i = 0; i < selected.length; i++) {
      const current = selected[i];
      setRows(prev => prev.map(r => r.id === current.id ? { ...r, status: 'running' } : r));
      await new Promise(r => setTimeout(r, 500));
      const score = Number((Math.min(0.95, 0.18 + i * 0.27)).toFixed(2));
      setRows(prev => prev.map(r => r.id === current.id ? { ...r, status: 'done', score, scoreColor: scoreColor(score), agentResponse: `Mock response for ticket ${r.ticket ?? 'N/A'}` } : r));
    }
    setRunStatus(`Completed and saved as ${testRunId}`);
    setRunning(false);
  };

  return (
    <AppShell padding="md">
      <Container size="xl">
        <Stack gap="lg">
          <Paper withBorder p="md">
            <Group justify="space-between">
              <div>
                <Title order={2}>RAG Evaluation Tool</Title>
                <Text c="dimmed">Frontend shell with history and sequential run flow.</Text>
              </div>
              <Group>
                <Badge variant="light">{historyMode ? 'Loaded Run' : 'Live Run'}</Badge>
                <ThemeToggle />
              </Group>
            </Group>
          </Paper>

          <Paper withBorder p="md">
            <Stack>
              <ChannelSelector channels={mockChannels} value={channelId} onChange={switchChannel} />
              <TextInput label="Test Id" value={testId} onChange={(e) => setTestId(e.currentTarget.value)} />
              <Text size="sm" c="dimmed">Selected: {selectedChannel?.name ?? 'None'} | Theme: {colorScheme}</Text>
            </Stack>
          </Paper>

          <Paper withBorder p="md">
            <Group justify="space-between" align="start">
              <Stack style={{ flex: 1 }}>
                <Title order={4}>Question Bank</Title>
                <QuestionList rows={rows} toggleRow={toggleRow} toggleAll={toggleAll} />
              </Stack>
              <Stack style={{ width: 320 }}>
                <Title order={4}>History</Title>
                <Group align="end">
                  <TextInput label="Date" value={historyDate} onChange={(e) => setHistoryDate(e.currentTarget.value)} />
                  <Select label="Test Id" placeholder="Choose run" data={[testId]} value={historyTestId} onChange={setHistoryTestId} />
                </Group>
                <Button onClick={loadHistory}>Load history</Button>
                <Text size="sm" c="dimmed">{runStatus}</Text>
              </Stack>
            </Group>
          </Paper>

          <Paper withBorder p="md">
            <TestRunner running={running} onRunSelected={() => run(false)} onRunAll={() => run(true)} />
          </Paper>

          <Paper withBorder p="md">
            <Stack>
              <Title order={4}>Results</Title>
              <ResultsColumn rows={rows} />
            </Stack>
          </Paper>

          <Button variant="light" onClick={() => setRows(mockQuestions[channelId ?? 'OATI'] ?? [])}>Reset mock data</Button>
        </Stack>
      </Container>
    </AppShell>
  );
}
