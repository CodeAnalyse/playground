import { Modal, TextInput, Textarea, NumberInput, Button, Stack } from '@mantine/core';
import { useState } from 'react';
import type { QuestionRow } from '../types';

export function QuestionForm({ opened, onClose, onSave, initial }: { opened: boolean; onClose: () => void; onSave: (value: { ticket: number; relatedQuestion: string; expectedResponse: string; }) => void; initial?: Partial<QuestionRow>; }) {
  const [ticket, setTicket] = useState<number | ''>(initial?.ticket ?? '');
  const [relatedQuestion, setRelatedQuestion] = useState(initial?.relatedQuestion ?? '');
  const [expectedResponse, setExpectedResponse] = useState(initial?.expectedResponse ?? '');

  return (
    <Modal opened={opened} onClose={onClose} title="Question">
      <Stack>
        <NumberInput label="Ticket" value={ticket} onChange={(v) => setTicket(v ?? '')} />
        <TextInput label="Related question" value={relatedQuestion} onChange={(e) => setRelatedQuestion(e.currentTarget.value)} />
        <Textarea label="Expected response" value={expectedResponse} onChange={(e) => setExpectedResponse(e.currentTarget.value)} autosize minRows={4} />
        <Button onClick={() => onSave({ ticket: Number(ticket), relatedQuestion, expectedResponse })}>Save</Button>
      </Stack>
    </Modal>
  );
}
