import React, { useEffect, useMemo, useState } from 'react';
import { createRoot, Root } from 'react-dom/client';
import { AppShell, Alert, Badge, Button, Container, Group, Loader, Paper, Select, Stack, Text, TextInput, Title } from '@mantine/core';
import { useLocalStorage } from '@mantine/hooks';
import { createApi } from './api';
import type { Channel, QuestionRow } from './types';
import { ThemeToggle } from './components/ThemeToggle';
import { ChannelSelector } from './components/ChannelSelector';
import { QuestionForm } from './components/QuestionForm';
import { QuestionList } from './components/QuestionList';
import { TestRunner } from './components/TestRunner';
import { ResultsColumn } from './components/ResultsColumn';

function scoreColor(score: number) { if (score <= 0) return 'Red'; if (score <= 0.25) return 'Orange'; if (score <= 0.5) return 'Yellow'; if (score <= 0.75) return 'Light Green'; return 'Green'; }
function mapQuestion(dto: any): QuestionRow { return { id: dto.id ?? dto._id ?? crypto.randomUUID(), ticket: dto.ticket, relatedQuestion: dto.relatedQuestion ?? dto.RelatedQuestion ?? '', expectedResponse: dto.expectedResponse ?? dto.ExpectedResponse ?? '', selected: false, status: 'idle' }; }

export class ResultAnalyserElement extends HTMLElement {
  private root?: Root;
  private mount?: HTMLDivElement;
  static get observedAttributes() { return ['api-base-url', 'default-channel', 'theme', 'auto-load', 'readonly', 'channel-id', 'test-id']; }
  connectedCallback() { if (!this.shadowRoot) this.attachShadow({ mode: 'open' }); if (!this.mount) { this.mount = document.createElement('div'); this.shadowRoot!.appendChild(this.mount); this.root = createRoot(this.mount); } this.renderWidget(); }
  disconnectedCallback() { this.root?.unmount(); }
  attributeChangedCallback() { this.renderWidget(); }
  private renderWidget() { if (!this.root) return; this.root.render(<WidgetApp host={this} />); }
}
export function registerResultAnalyser() { if (!customElements.get('result-analyser')) customElements.define('result-analyser', ResultAnalyserElement); }

function WidgetApp({ host }: { host: ResultAnalyserElement }) {
  const apiBaseUrl = host.getAttribute('api-base-url') ?? '';
  const readonly = host.hasAttribute('readonly');
  const defaultChannel = host.getAttribute('default-channel');
  const autoLoad = host.hasAttribute('auto-load');
  const initialTheme = (host.getAttribute('theme') as 'light' | 'dark' | null) ?? 'light';
  const [theme, setTheme] = useLocalStorage<'light' | 'dark'>({ key: 'result-analyser-theme', defaultValue: initialTheme });
  const api = useMemo(() => createApi(apiBaseUrl), [apiBaseUrl]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [channelId, setChannelId] = useState<string | null>(defaultChannel);
  const [rows, setRows] = useState<QuestionRow[]>([]);
  const [running, setRunning] = useState(false);
  const [loading, setLoading] = useState(false);
  const [warn, setWarn] = useState<string | null>(null);
  const [historyItems, setHistoryItems] = useState<string[]>([]);
  const [historyTestId, setHistoryTestId] = useState<string | null>(host.getAttribute('test-id'));
  const [historyMode, setHistoryMode] = useState(false);
  const [formOpened, setFormOpened] = useState(false);
  const [editRow, setEditRow] = useState<QuestionRow | null>(null);
  const [runStatus, setRunStatus] = useState('Ready');
  const selectedChannel = useMemo(() => channels.find(c => c.id === channelId) ?? null, [channels, channelId]);
  const selectedRows = rows.filter(r => r.selected);

  const failSoft = async <T,>(fn: () => Promise<T>, fallback: T, msg?: string): Promise<T> => {
    try { return await fn(); } catch (e: any) { if (msg) setWarn(e?.message ?? msg); return fallback; }
  };

  async function loadChannels() {
    setLoading(true);
    setWarn(null);
    const data = await failSoft(() => api.loadChannels(), [], 'Failed to load channels');
    setChannels(data);
    const def = data.find((x: any) => x.isDefault) ?? data[0];
    const resolved = defaultChannel || def?.id || null;
    setChannelId(resolved);
    if (resolved) await loadQuestions(resolved);
    setLoading(false);
  }

  async function loadQuestions(channel: string) {
    setLoading(true);
    setWarn(null);
    const data = await failSoft(() => api.loadQuestions(channel), [], 'Failed to load questions');
    setRows(data.map(mapQuestion));
    setLoading(false);
  }

  async function loadHistoryItems() {
    setLoading(true);
    setWarn(null);
    const data = await failSoft(() => api.loadRunDates(), [], 'Failed to load history');
    setHistoryItems(data);
    setLoading(false);
  }

  async function loadHistory() {
    if (!historyTestId) return;
    setLoading(true);
    setWarn(null);
    const run = await failSoft(() => api.loadRun(historyTestId), null as any, 'Failed to load run');
    if (run) {
      const mapped: QuestionRow[] = (run.results ?? []).map((x: any, i: number) => ({ id: x.questionId ?? String(i), ticket: x.ticket, relatedQuestion: x.relatedQuestion, expectedResponse: x.expectedResponse, selected: false, status: 'done', score: x.semanticSimilarityScore, scoreColor: x.scoreColor ?? scoreColor(x.semanticSimilarityScore), agentResponse: x.agentResponse }));
      setRows(mapped);
      setRunStatus(`Loaded ${run.testId}`);
      setHistoryMode(true);
    } else {
      setRows([]);
      setHistoryMode(false);
      setRunStatus('History unavailable');
    }
    setLoading(false);
  }

  const toggleRow = (id: string) => setRows(prev => prev.map(r => r.id === id ? { ...r, selected: !r.selected } : r));
  const toggleAll = (checked: boolean) => setRows(prev => prev.map(r => ({ ...r, selected: checked })));
  const openCreate = () => { setEditRow(null); setFormOpened(true); };
  const openEdit = (row: QuestionRow) => { setEditRow(row); setFormOpened(true); };

  async function saveQuestion(payload: any) {
    setLoading(true);
    const ok = await failSoft(async () => { if (editRow) await api.updateQuestion(editRow.id, payload); else await api.createQuestion(payload); return true; }, false, 'Save failed');
    if (ok && channelId) await loadQuestions(channelId);
    setFormOpened(false);
    setEditRow(null);
    setLoading(false);
  }

  async function deleteQuestion(row: QuestionRow) {
    setLoading(true);
    const ok = await failSoft(() => api.deleteQuestion(row.id), true, 'Delete failed');
    if (ok && channelId) await loadQuestions(channelId);
    setLoading(false);
  }

  async function run(all: boolean) {
    setRunning(true);
    setWarn(null);
    setHistoryMode(false);
    const selected = all ? rows : rows.filter(r => r.selected);
    const runId = host.getAttribute('test-id') || `TEST-${new Date().toISOString().slice(0,10).replaceAll('-', '')}-001`;
    const results: any[] = [];
    for (const current of selected) {
      setRows(prev => prev.map(r => r.id === current.id ? { ...r, status: 'running' } : r));
      const conversationId = crypto.randomUUID();
      const genie = await failSoft(() => api.geniePrompt({ prompt: current.relatedQuestion, conversation_id: conversationId, action: 'Default', additional_data: { report_outages: [] }, files: [], metadata: { product: selectedChannel?.name ?? '', data_source: [selectedChannel?.dataSource?.[0] ?? ''], channel: { name: selectedChannel?.name ?? '', id: selectedChannel?.id ?? '' } } }), { response: '', prompt_id: null });
      const evalResp = await failSoft(() => api.evaluate({ user_prompt: current.relatedQuestion, agent_response: genie.response ?? '', expected_response: current.expectedResponse, conversation_id: conversationId }), { semantic_similarity_score: 0 });
      const score = Number(evalResp.semantic_similarity_score ?? 0);
      const color = scoreColor(score);
      results.push({ questionId: current.id, ticket: current.ticket, relatedQuestion: current.relatedQuestion, expectedResponse: current.expectedResponse, agentResponse: genie.response ?? '', semanticSimilarityScore: score, scoreColor: color, conversationId, promptId: genie.prompt_id, status: 'Completed', error: null, startedAt: new Date().toISOString(), completedAt: new Date().toISOString() });
      setRows(prev => prev.map(r => r.id === current.id ? { ...r, status: 'done', score, scoreColor: color, agentResponse: genie.response ?? '' } : r));
    }
    await failSoft(() => api.saveRun({ testId: runId, runDate: new Date().toISOString(), channel: { id: selectedChannel?.id ?? '', name: selectedChannel?.name ?? '', datasource: selectedChannel?.dataSource?.[0] ?? '', product: selectedChannel?.name ?? '' }, totalQuestions: selected.length, completedQuestions: selected.length, failedQuestions: 0, results }), undefined);
    setRunStatus(`Completed${results.length ? ` and saved as ${runId}` : ''}`);
    setRunning(false);
  }

  useEffect(() => { void loadChannels(); }, [defaultChannel]);
  useEffect(() => { if (historyTestId) void loadHistoryItems(); }, [historyTestId]);
  useEffect(() => { if (autoLoad && channelId) void loadQuestions(channelId); }, [autoLoad, channelId]);

  return <AppShell padding="md"><Container size="xl"><Stack gap="lg"><Paper withBorder p="md"><Group justify="space-between"><div><Title order={2}>Result Analyser</Title><Text c="dimmed">Embedded widget with real APIs.</Text></div><Group><Badge variant="light">{historyMode ? 'Loaded Run' : 'Live Run'}</Badge><ThemeToggle theme={theme} onToggle={() => setTheme(theme === 'dark' ? 'light' : 'dark')} /></Group></Group></Paper>{warn && <Alert color="yellow" title="Warning">{warn}</Alert>}{loading && <Group><Loader size="sm" /><Text size="sm">Loading...</Text></Group>}<Paper withBorder p="md"><Stack><TextInput label="API Base" value={apiBaseUrl} readOnly /><ChannelSelector channels={channels} value={channelId} onChange={setChannelId} /><Text size="sm" c="dimmed">Selected: {selectedChannel?.name ?? 'None'}</Text></Stack></Paper><Paper withBorder p="md"><Group justify="space-between" align="start"><Stack style={{ flex: 1 }}><Group justify="space-between"><Title order={4}>Question Bank</Title>{!readonly && <Group><Button onClick={openCreate}>Create</Button><Button variant="outline" disabled={!selectedRows.length} onClick={() => openEdit(selectedRows[0] ?? rows[0])}>Edit</Button><Button color="red" variant="light" disabled={!selectedRows.length} onClick={() => selectedRows.forEach(r => void deleteQuestion(r))}>Delete</Button></Group>}</Group><QuestionList rows={rows} toggleRow={toggleRow} toggleAll={toggleAll} onEdit={openEdit} onDelete={deleteQuestion} /></Stack><Stack style={{ width: 360 }}><Title order={4}>History</Title><Select label="Test Id" placeholder="Choose run" data={historyItems} value={historyTestId} onChange={setHistoryTestId} searchable /><Button onClick={loadHistory} disabled={!historyTestId}>Load history</Button><Text size="sm" c="dimmed">{runStatus}</Text></Stack></Group></Paper><Paper withBorder p="md"><TestRunner running={running} onRunSelected={() => void run(false)} onRunAll={() => void run(true)} /></Paper><Paper withBorder p="md"><Stack><Title order={4}>Results</Title><ResultsColumn rows={rows} /></Stack></Paper><QuestionForm opened={formOpened} onClose={() => setFormOpened(false)} onSave={saveQuestion} initial={editRow ?? undefined} channelName={selectedChannel?.id ?? 'OATI'} /></Stack></Container></AppShell>;
}
