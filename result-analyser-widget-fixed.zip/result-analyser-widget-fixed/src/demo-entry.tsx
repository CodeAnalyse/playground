import React from 'react';
import ReactDOM from 'react-dom/client';
import { MantineProvider } from '@mantine/core';
import { registerResultAnalyser } from './widget';

registerResultAnalyser();

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <MantineProvider>
      <div style={{ padding: 24 }}>Demo page. Use <code>&lt;result-analyser&gt;</code> in HTML.</div>
    </MantineProvider>
  </React.StrictMode>
);
