import { registerResultAnalyser } from './widget';
registerResultAnalyser();
