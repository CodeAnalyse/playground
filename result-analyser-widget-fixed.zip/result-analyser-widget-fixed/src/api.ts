export function createApi(baseUrl: string) {
  const u = (p: string) => `${baseUrl.replace(/\/$/, '')}${p}`;
  const r = async (i: RequestInfo, init?: RequestInit) => {
    const res = await fetch(i, { headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) }, ...init });
    if (!res.ok) throw new Error(await res.text());
    if (res.status === 204) return undefined as any;
    return res.json();
  };
  return {
    loadChannels: () => r(u('/channel/list'), { method: 'POST', body: '{}' }),
    loadQuestions: (channelId: string) => r(u(`/api/predefined-questions?channelId=${encodeURIComponent(channelId)}`)),
    createQuestion: (payload: any) => r(u('/api/predefined-questions'), { method: 'POST', body: JSON.stringify(payload) }),
    updateQuestion: (id: string, payload: any) => r(u(`/api/predefined-questions/${encodeURIComponent(id)}`), { method: 'PUT', body: JSON.stringify(payload) }),
    deleteQuestion: (id: string) => r(u(`/api/predefined-questions/${encodeURIComponent(id)}`), { method: 'DELETE' }),
    saveRun: (payload: any) => r(u('/api/test-runs'), { method: 'POST', body: JSON.stringify(payload) }),
    loadRun: (testId: string) => r(u(`/api/test-runs/${encodeURIComponent(testId)}`)),
    loadRunDates: () => r(u('/api/test-runs/dates')),
    geniePrompt: (payload: any) => r(u('/Genie/UserPrompt'), { method: 'POST', body: JSON.stringify(payload) }),
    evaluate: (payload: any) => r(u('/Evaluation/SemanticSimilarity'), { method: 'POST', body: JSON.stringify(payload) })
  };
}
