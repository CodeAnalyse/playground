import { Select } from '@mantine/core';
import type { Channel } from '../types';
export function ChannelSelector({ channels, value, onChange }: { channels: Channel[]; value: string | null; onChange: (id: string | null) => void; }) { return <Select label="Channel" placeholder="Select channel" data={channels.map(c => ({ value: c.id, label: `${c.name}${c.isDefault ? ' (default)' : ''}` }))} value={value} onChange={onChange} searchable clearable />; }
