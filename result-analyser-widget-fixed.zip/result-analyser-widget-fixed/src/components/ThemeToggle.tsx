import { ActionIcon, Tooltip } from '@mantine/core';
export function ThemeToggle({ theme, onToggle }: { theme: 'light' | 'dark'; onToggle: () => void }) { return <Tooltip label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}><ActionIcon variant="light" onClick={onToggle} aria-label="Toggle theme">{theme === 'dark' ? '☀' : '🌙'}</ActionIcon></Tooltip>; }
