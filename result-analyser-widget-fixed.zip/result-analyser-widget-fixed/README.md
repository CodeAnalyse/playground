# Result Analyser Widget

## Build
```bash
npm install
npm run build
```

This produces `dist/result-analyser.js`.

## Usage
```html
<script src="result-analyser.js"></script>
<result-analyser api-base-url="https://api.example.com" theme="dark" default-channel="OATI"></result-analyser>
```
