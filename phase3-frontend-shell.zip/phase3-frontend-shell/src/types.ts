export type Channel = {
  id: string;
  name: string;
  dataSource: string[];
  environment: string | null;
  envColor: string | null;
  type: string;
  isDefault: boolean;
};

export type QuestionRow = {
  id: string;
  ticket: number;
  relatedQuestion: string;
  expectedResponse: string;
  selected: boolean;
  status: 'idle' | 'running' | 'done' | 'error';
  score?: number;
  scoreColor?: string;
  agentResponse?: string;
  error?: string;
};
