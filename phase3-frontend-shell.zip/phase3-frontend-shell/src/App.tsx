import { useMemo, useState } from 'react';
import { AppShell, Badge, Button, Container, Group, Paper, Stack, Text, Title } from '@mantine/core';
import { ChannelSelector } from './components/ChannelSelector';
import { QuestionList } from './components/QuestionList';
import { TestRunner } from './components/TestRunner';
import { ResultsColumn } from './components/ResultsColumn';
import { HistoricalRunSelector } from './components/HistoricalRunSelector';
import { mockChannels, mockQuestions } from './mockData';
import type { QuestionRow } from './types';

export default function App() {
  const [channelId, setChannelId] = useState<string | null>('OATI');
  const [running, setRunning] = useState(false);
  const [historyDate, setHistoryDate] = useState('2026-07-08');
  const [historyTestId, setHistoryTestId] = useState<string | null>(null);
  const [rows, setRows] = useState<QuestionRow[]>(mockQuestions['OATI']);

  const selectedChannel = useMemo(() => mockChannels.find(c => c.id === channelId) ?? null, [channelId]);

  const toggleRow = (id: string) => setRows(prev => prev.map(r => r.id === id ? { ...r, selected: !r.selected } : r));
  const toggleAll = (checked: boolean) => setRows(prev => prev.map(r => ({ ...r, selected: checked })));

  const run = async (all: boolean) => {
    setRunning(true);
    await new Promise(r => setTimeout(r, 700));
    setRows(prev => prev.map((r, i) => ({
      ...r,
      status: (all || r.selected) ? 'done' : r.status,
      score: (all || r.selected) ? Number((0.2 + i * 0.3).toFixed(2)) : r.score,
      scoreColor: (all || r.selected) ? (i === 0 ? 'Orange' : i === 1 ? 'Yellow' : 'Green') : r.scoreColor,
      agentResponse: (all || r.selected) ? `Mock response for ticket ${r.ticket}` : r.agentResponse
    })));
    setRunning(false);
  };

  return (
    <AppShell padding="md">
      <Container size="xl">
        <Stack gap="lg">
          <Paper withBorder p="md">
            <Group justify="space-between">
              <div>
                <Title order={2}>RAG Evaluation Tool</Title>
                <Text c="dimmed">Phase 3 frontend shell, independent of .NET code.</Text>
              </div>
              <Badge variant="light">Shell</Badge>
            </Group>
          </Paper>

          <Paper withBorder p="md">
            <Stack>
              <ChannelSelector channels={mockChannels} value={channelId} onChange={setChannelId} />
              <Text size="sm" c="dimmed">Selected: {selectedChannel?.name ?? 'None'}</Text>
            </Stack>
          </Paper>

          <Paper withBorder p="md">
            <Group justify="space-between" align="start">
              <Stack style={{ flex: 1 }}>
                <Title order={4}>Question Bank</Title>
                <QuestionList rows={rows} toggleRow={toggleRow} toggleAll={toggleAll} />
              </Stack>
              <Stack style={{ width: 320 }}>
                <Title order={4}>History</Title>
                <HistoricalRunSelector date={historyDate} testId={historyTestId} onDateChange={setHistoryDate} onTestIdChange={setHistoryTestId} onLoad={() => undefined} />
                <Text size="sm" c="dimmed">This is UI-only in shell mode.</Text>
              </Stack>
            </Group>
          </Paper>

          <Paper withBorder p="md">
            <TestRunner running={running} onRunSelected={() => run(false)} onRunAll={() => run(true)} />
          </Paper>

          <Paper withBorder p="md">
            <Stack>
              <Title order={4}>Results</Title>
              <ResultsColumn rows={rows} />
            </Stack>
          </Paper>

          <Button variant="light" onClick={() => setRows(mockQuestions[channelId ?? 'OATI'] ?? [])}>Reset mock data</Button>
        </Stack>
      </Container>
    </AppShell>
  );
}
