# Result Analyser Widget

Use as a custom element:

```html
<script src="result-analyser.js"></script>
<result-analyser api-base-url="https://your-api" theme="dark" default-channel="OATI" auto-load readonly></result-analyser>
```

## Attributes
- `api-base-url`
- `default-channel`
- `theme`
- `auto-load`
- `readonly`
- `channel-id`
- `test-id`

## Build
```bash
npm install
npm run build
```
