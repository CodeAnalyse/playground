var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddReverseProxy()
    .LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));

var app = builder.Build();

app.MapGet("/", () => Results.Text("YARP proxy is running. Try /GeniePlatform/chat", "text/plain"));
app.MapGet("/health", () => Results.Ok(new { status = "ok", proxy = "yarp", target = "http://127.0.0.1:8000" }));

app.MapReverseProxy();

app.Run();
