# YARP Reverse Proxy Sample

This is a minimal ASP.NET Core 8 + YARP sample that proxies:

- Public URL: `http://localhost:8080/GeniePlatform/chat`
- Target URL: `http://127.0.0.1:8000/chat`

It also forwards nested paths, for example:

- `http://localhost:8080/GeniePlatform/chat/trace`
- to `http://127.0.0.1:8000/chat/trace`

## Files

- `Program.cs` - app startup and reverse proxy mapping
- `appsettings.json` - YARP route and destination config
- `YarpProxySample.csproj` - .NET 8 project file with YARP package

## Prerequisites

- .NET 8 SDK
- Your FastAPI app running locally on `http://127.0.0.1:8000`

## Run

```bash
dotnet restore
dotnet run
```

The proxy will listen on:

- `http://localhost:8080`

## Test

Open these URLs in a browser or Postman:

- `http://localhost:8080/health`
- `http://localhost:8080/GeniePlatform/chat`
- `http://localhost:8080/GeniePlatform/chat/trace`

## How the path rewrite works

Incoming request:

- `/GeniePlatform/chat`

YARP transform:

- removes `/GeniePlatform`

Forwarded request:

- `/chat`

So your FastAPI router can stay as:

```python
@router.post("/chat")
async def chat(...):
    ...
```

## If you want your real domain

If your public URL is:

- `http://i-sandeepb.dev.oati.local/GeniePlatform/chat`

then either:

1. bind this ASP.NET Core app to that host/port, or
2. put IIS in front of this YARP app and let IIS forward to `http://localhost:8080`

## Optional change: proxy the whole GeniePlatform area

If later you want more paths such as `/GeniePlatform/users`, `/GeniePlatform/docs`, etc., add more YARP routes or use a broader route pattern.
