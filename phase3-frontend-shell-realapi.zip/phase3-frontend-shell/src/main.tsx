import React from 'react';
import ReactDOM from 'react-dom/client';
import { MantineProvider } from '@mantine/core';
import { useLocalStorage } from '@mantine/hooks';
import '@mantine/core/styles.css';
import App from './App';

function Root() {
  const [colorScheme, setColorScheme] = useLocalStorage<'light' | 'dark'>({ key: 'theme', defaultValue: 'light' });
  return (
    <MantineProvider defaultColorScheme={colorScheme} theme={{ primaryColor: 'blue' }}>
      <App colorScheme={colorScheme} setColorScheme={setColorScheme} />
    </MantineProvider>
  );
}

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <Root />
  </React.StrictMode>
);
