import { Modal, TextInput, Textarea, NumberInput, Button, Stack, Group } from '@mantine/core';
import { useEffect, useState } from 'react';
import type { QuestionRow } from '../types';
import type { QuestionPayload } from '../types';

export function QuestionForm({ opened, onClose, onSave, initial }: { opened: boolean; onClose: () => void; onSave: (value: QuestionPayload) => Promise<void> | void; initial?: Partial<QuestionRow> & { id?: string }; }) {
  const [ticket, setTicket] = useState<number | ''>(initial?.ticket ?? '');
  const [relatedQuestion, setRelatedQuestion] = useState(initial?.relatedQuestion ?? '');
  const [expectedResponse, setExpectedResponse] = useState(initial?.expectedResponse ?? '');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setTicket(initial?.ticket ?? '');
    setRelatedQuestion(initial?.relatedQuestion ?? '');
    setExpectedResponse(initial?.expectedResponse ?? '');
  }, [initial, opened]);

  const submit = async () => {
    setSaving(true);
    await onSave({
      ticket: ticket === '' ? undefined : Number(ticket),
      relatedQuestion,
      expectedResponse,
      channel: { id: 'OATI', name: 'OATI', dataSource: 'energy_public', product: 'OATI' }
    });
    setSaving(false);
  };

  return (
    <Modal opened={opened} onClose={onClose} title={initial?.id ? 'Edit question' : 'Create question'} size="lg">
      <Stack>
        <NumberInput label="Ticket" value={ticket} onChange={(v) => setTicket(v ?? '')} placeholder="Optional" />
        <TextInput label="Related question" value={relatedQuestion} onChange={(e) => setRelatedQuestion(e.currentTarget.value)} />
        <Textarea label="Expected response" value={expectedResponse} onChange={(e) => setExpectedResponse(e.currentTarget.value)} autosize minRows={4} />
        <Group justify="flex-end">
          <Button variant="default" onClick={onClose}>Cancel</Button>
          <Button onClick={submit} loading={saving}>Save</Button>
        </Group>
      </Stack>
    </Modal>
  );
}
