import { Button, Group, Text } from '@mantine/core';

export function TestRunner({ onRunSelected, onRunAll, running }: { onRunSelected: () => void; onRunAll: () => void; running: boolean; }) {
  return (
    <Group>
      <Button onClick={onRunSelected} loading={running}>Run selected</Button>
      <Button variant="light" onClick={onRunAll} loading={running}>Run all</Button>
      <Text size="sm" c="dimmed">Runs are sequential by design.</Text>
    </Group>
  );
}
