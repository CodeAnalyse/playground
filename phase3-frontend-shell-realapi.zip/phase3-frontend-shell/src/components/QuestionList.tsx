import { Table, Checkbox, Text, Badge } from '@mantine/core';
import type { QuestionRow } from '../types';

export function QuestionList({ rows, toggleRow, toggleAll }: { rows: QuestionRow[]; toggleRow: (id: string) => void; toggleAll: (checked: boolean) => void; }) {
  const allChecked = rows.length > 0 && rows.every(r => r.selected);
  const someChecked = rows.some(r => r.selected) && !allChecked;
  return (
    <Table striped highlightOnHover withTableBorder withColumnBorders>
      <Table.Thead>
        <Table.Tr>
          <Table.Th style={{ width: 48 }}>
            <Checkbox checked={allChecked} indeterminate={someChecked} onChange={(e) => toggleAll(e.currentTarget.checked)} />
          </Table.Th>
          <Table.Th>Ticket</Table.Th>
          <Table.Th>Question</Table.Th>
          <Table.Th>Status</Table.Th>
          <Table.Th>Score</Table.Th>
        </Table.Tr>
      </Table.Thead>
      <Table.Tbody>
        {rows.map(row => (
          <Table.Tr key={row.id}>
            <Table.Td><Checkbox checked={row.selected} onChange={() => toggleRow(row.id)} /></Table.Td>
            <Table.Td>{row.ticket}</Table.Td>
            <Table.Td><Text size="sm">{row.relatedQuestion}</Text></Table.Td>
            <Table.Td><Badge variant="light">{row.status}</Badge></Table.Td>
            <Table.Td>{row.score ?? '-'}</Table.Td>
          </Table.Tr>
        ))}
      </Table.Tbody>
    </Table>
  );
}
