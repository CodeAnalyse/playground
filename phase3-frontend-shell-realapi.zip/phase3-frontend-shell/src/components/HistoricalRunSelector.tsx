import { Group, Select, Button, Stack, TextInput } from '@mantine/core';

export function HistoricalRunSelector({ date, testId, onDateChange, onTestIdChange, onLoad }: { date: string; testId: string | null; onDateChange: (v: string) => void; onTestIdChange: (v: string | null) => void; onLoad: () => void; }) {
  return (
    <Stack gap="xs">
      <Group align="end">
        <TextInput label="Date" value={date} onChange={(e) => onDateChange(e.currentTarget.value)} placeholder="YYYY-MM-DD" />
        <Select label="Test Id" placeholder="Choose run" data={[]} value={testId} onChange={onTestIdChange} />
        <Button onClick={onLoad}>Load</Button>
      </Group>
    </Stack>
  );
}
