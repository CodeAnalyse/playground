import { Badge, Table } from '@mantine/core';
import type { QuestionRow } from '../types';

export function ResultsColumn({ rows }: { rows: QuestionRow[] }) {
  return (
    <Table withTableBorder>
      <Table.Thead>
        <Table.Tr><Table.Th>Ticket</Table.Th><Table.Th>Score</Table.Th><Table.Th>Color</Table.Th><Table.Th>Response</Table.Th></Table.Tr>
      </Table.Thead>
      <Table.Tbody>
        {rows.map(r => (
          <Table.Tr key={r.id}>
            <Table.Td>{r.ticket}</Table.Td>
            <Table.Td>{r.score ?? '-'}</Table.Td>
            <Table.Td><Badge variant="light">{r.scoreColor ?? 'Idle'}</Badge></Table.Td>
            <Table.Td>{r.agentResponse ?? '-'}</Table.Td>
          </Table.Tr>
        ))}
      </Table.Tbody>
    </Table>
  );
}
