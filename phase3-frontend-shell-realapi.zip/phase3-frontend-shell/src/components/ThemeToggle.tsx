import { ActionIcon, Tooltip } from '@mantine/core';
import { useComputedColorScheme, useMantineColorScheme } from '@mantine/core';

export function ThemeToggle() {
  const { setColorScheme } = useMantineColorScheme();
  const computed = useComputedColorScheme('light', { getInitialValueInEffect: true });
  return (
    <Tooltip label={`Switch to ${computed === 'dark' ? 'light' : 'dark'} mode`}>
      <ActionIcon variant="light" onClick={() => setColorScheme(computed === 'dark' ? 'light' : 'dark')} aria-label="Toggle theme">
        {computed === 'dark' ? '☀' : '🌙'}
      </ActionIcon>
    </Tooltip>
  );
}
