import { useEffect, useMemo, useState } from 'react';
import { AppShell, Badge, Button, Container, Group, Paper, Stack, Text, Title, Select, TextInput, Table, Checkbox, Loader, Alert } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { ChannelSelector } from './components/ChannelSelector';
import { QuestionForm } from './components/QuestionForm';
import { TestRunner } from './components/TestRunner';
import { ResultsColumn } from './components/ResultsColumn';
import { ThemeToggle } from './components/ThemeToggle';
import { API } from './api';
import type { Channel, QuestionRow, QuestionPayload } from './types';

function scoreColor(score: number) {
  if (score <= 0) return 'Red';
  if (score <= 0.25) return 'Orange';
  if (score <= 0.5) return 'Yellow';
  if (score <= 0.75) return 'Light Green';
  return 'Green';
}

async function fetchJson<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json', ...(options?.headers || {}) },
    ...options
  });
  if (!res.ok) throw new Error(await res.text());
  if (res.status === 204) return undefined as T;
  return res.json();
}

function mapQuestion(dto: any): QuestionRow {
  return {
    id: dto.id ?? dto._id ?? crypto.randomUUID(),
    ticket: dto.ticket,
    relatedQuestion: dto.relatedQuestion ?? dto.RelatedQuestion ?? '',
    expectedResponse: dto.expectedResponse ?? dto.ExpectedResponse ?? '',
    selected: false,
    status: 'idle'
  };
}

export default function App({ colorScheme }: { colorScheme: 'light' | 'dark'; setColorScheme: (v: 'light' | 'dark') => void; }) {
  const [channelId, setChannelId] = useState<string | null>(null);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [rows, setRows] = useState<QuestionRow[]>([]);
  const [running, setRunning] = useState(false);
  const [historyDate, setHistoryDate] = useState('2026-07-08');
  const [historyTestId, setHistoryTestId] = useState<string | null>(null);
  const [historyMode, setHistoryMode] = useState(false);
  const [testId, setTestId] = useState('');
  const [runStatus, setRunStatus] = useState('Ready');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formOpen, { open: openForm, close: closeForm }] = useDisclosure(false);
  const [editRow, setEditRow] = useState<QuestionRow | null>(null);

  const selectedChannel = useMemo(() => channels.find(c => c.id === channelId) ?? null, [channels, channelId]);
  const selectedRows = rows.filter(r => r.selected);

  useEffect(() => {
    void loadChannels();
  }, []);

  useEffect(() => {
    if (channelId) void loadQuestions(channelId);
  }, [channelId]);

  async function loadChannels() {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchJson<any[]>(API.CHANNEL_LIST, { method: 'POST', body: '{}' });
      setChannels(data);
      const def = data.find(x => x.isDefault) ?? data[0] ?? null;
      setChannelId(def?.id ?? null);
    } catch (e: any) {
      setError(e?.message ?? 'Failed to load channels');
    } finally {
      setLoading(false);
    }
  }

  async function loadQuestions(channel: string) {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchJson<any[]>(`${API.PREDEFINED_QUESTIONS}?channelId=${encodeURIComponent(channel)}`);
      setRows(data.map(mapQuestion));
    } catch (e: any) {
      setError(e?.message ?? 'Failed to load questions');
    } finally {
      setLoading(false);
    }
  }

  async function createQuestion(payload: QuestionPayload) {
    try {
      setLoading(true);
      await fetchJson(API.PREDEFINED_QUESTIONS, { method: 'POST', body: JSON.stringify(payload) });
      await loadQuestions(channelId ?? '');
      closeForm();
    } catch (e: any) {
      setError(e?.message ?? 'Failed to create question');
    } finally {
      setLoading(false);
    }
  }

  async function updateQuestion(id: string, payload: QuestionPayload) {
    try {
      setLoading(true);
      await fetchJson(`${API.PREDEFINED_QUESTIONS}/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
      await loadQuestions(channelId ?? '');
      closeForm();
    } catch (e: any) {
      setError(e?.message ?? 'Failed to update question');
    } finally {
      setLoading(false);
    }
  }

  async function deleteQuestion(id: string) {
    try {
      setLoading(true);
      await fetchJson(`${API.PREDEFINED_QUESTIONS}/${id}`, { method: 'DELETE' });
      await loadQuestions(channelId ?? '');
    } catch (e: any) {
      setError(e?.message ?? 'Failed to delete question');
    } finally {
      setLoading(false);
    }
  }

  const toggleRow = (id: string) => setRows(prev => prev.map(r => r.id === id ? { ...r, selected: !r.selected } : r));
  const toggleAll = (checked: boolean) => setRows(prev => prev.map(r => ({ ...r, selected: checked })));

  const openCreate = () => { setEditRow(null); openForm(); };
  const openEdit = (row: QuestionRow) => { setEditRow(row); openForm(); };

  const saveQuestion = async (payload: QuestionPayload) => {
    if (editRow) await updateQuestion(editRow.id, payload);
    else await createQuestion(payload);
  };

  const loadHistory = async () => {
    try {
      setLoading(true);
      setHistoryMode(true);
      const run = await fetchJson<any>(`${API.TEST_RUNS}/${encodeURIComponent(historyTestId ?? '')}`);
      const mapped: QuestionRow[] = (run.results ?? []).map((x: any, i: number) => ({
        id: x.questionId ?? String(i),
        ticket: x.ticket,
        relatedQuestion: x.relatedQuestion,
        expectedResponse: x.expectedResponse,
        selected: false,
        status: 'done',
        score: x.semanticSimilarityScore,
        scoreColor: x.scoreColor ?? scoreColor(x.semanticSimilarityScore),
        agentResponse: x.agentResponse
      }));
      setRows(mapped);
      setTestId(run.testId ?? '');
      setRunStatus(`Loaded ${run.testId}`);
    } catch (e: any) {
      setError(e?.message ?? 'Failed to load history');
    } finally {
      setLoading(false);
    }
  };

  const run = async (all: boolean) => {
    try {
      setRunning(true);
      setHistoryMode(false);
      setRunStatus('Running...');
      setError(null);
      const selected = (all ? rows : rows.filter(r => r.selected));
      const runId = `TEST-${new Date().toISOString().slice(0,10).replaceAll('-','')}-001`;
      setTestId(runId);
      const results: any[] = [];
      for (let i = 0; i < selected.length; i++) {
        const current = selected[i];
        setRows(prev => prev.map(r => r.id === current.id ? { ...r, status: 'running' } : r));
        const conversationId = crypto.randomUUID();
        const geniePayload = {
          prompt: current.relatedQuestion,
          conversation_id: conversationId,
          action: 'Default',
          additional_data: { report_outages: [] },
          files: [],
          metadata: {
            product: selectedChannel?.name ?? '',
            data_source: [selectedChannel?.dataSource?.[0] ?? ''],
            channel: { name: selectedChannel?.name ?? '', id: selectedChannel?.id ?? '' }
          }
        };
        const genie = await fetchJson<any>(API.GENIE_USER_PROMPT, { method: 'POST', body: JSON.stringify(geniePayload) });
        const evalPayload = {
          user_prompt: current.relatedQuestion,
          agent_response: genie.response ?? '',
          expected_response: current.expectedResponse,
          conversation_id: conversationId
        };
        const scoreResp = await fetchJson<any>(API.EVALUATION_SIMILARITY, { method: 'POST', body: JSON.stringify(evalPayload) });
        const score = Number(scoreResp.semantic_similarity_score ?? 0);
        const color = scoreColor(score);
        const updated = {
          ...current,
          status: 'done' as const,
          score,
          scoreColor: color,
          agentResponse: genie.response ?? '',
          error: undefined
        };
        results.push({
          questionId: current.id,
          ticket: current.ticket,
          relatedQuestion: current.relatedQuestion,
          expectedResponse: current.expectedResponse,
          agentResponse: genie.response ?? '',
          semanticSimilarityScore: score,
          scoreColor: color,
          conversationId,
          promptId: genie.prompt_id,
          status: 'Completed',
          error: null,
          startedAt: new Date().toISOString(),
          completedAt: new Date().toISOString()
        });
        setRows(prev => prev.map(r => r.id === current.id ? updated : r));
      }
      await fetchJson(API.TEST_RUNS, { method: 'POST', body: JSON.stringify({
        testId: runId,
        runDate: new Date().toISOString(),
        channel: {
          id: selectedChannel?.id ?? '',
          name: selectedChannel?.name ?? '',
          datasource: selectedChannel?.dataSource?.[0] ?? '',
          product: selectedChannel?.name ?? ''
        },
        totalQuestions: selected.length,
        completedQuestions: selected.length,
        failedQuestions: 0,
        results
      }) });
      setRunStatus(`Completed and saved as ${runId}`);
    } catch (e: any) {
      setError(e?.message ?? 'Run failed');
      setRunStatus('Run failed');
    } finally {
      setRunning(false);
    }
  };

  return (
    <AppShell padding="md">
      <Container size="xl">
        <Stack gap="lg">
          <Paper withBorder p="md">
            <Group justify="space-between">
              <div>
                <Title order={2}>RAG Evaluation Tool</Title>
                <Text c="dimmed">CRUD, sequential runs, and historical replay.</Text>
              </div>
              <Group>
                <Badge variant="light">{historyMode ? 'Loaded Run' : 'Live Run'}</Badge>
                <ThemeToggle />
              </Group>
            </Group>
          </Paper>

          {error && <Alert color="red" title="Error">{error}</Alert>}
          {loading && <Group><Loader size="sm" /><Text size="sm">Loading...</Text></Group>}

          <Paper withBorder p="md">
            <Stack>
              <ChannelSelector channels={channels} value={channelId} onChange={setChannelId} />
              <Group>
                <TextInput label="Test Id" value={testId} onChange={(e) => setTestId(e.currentTarget.value)} />
                <Text size="sm" c="dimmed">Theme: {colorScheme}</Text>
              </Group>
              <Text size="sm" c="dimmed">Selected: {selectedChannel?.name ?? 'None'}</Text>
            </Stack>
          </Paper>

          <Paper withBorder p="md">
            <Group justify="space-between" align="start">
              <Stack style={{ flex: 1 }}>
                <Group justify="space-between">
                  <Title order={4}>Question Bank</Title>
                  <Group>
                    <Button onClick={openCreate}>Create</Button>
                    <Button variant="outline" disabled={!selectedRows.length} onClick={() => openEdit(selectedRows[0] ?? rows[0])}>Edit</Button>
                    <Button color="red" variant="light" disabled={!selectedRows.length} onClick={() => selectedRows.forEach(r => void deleteQuestion(r.id))}>Delete</Button>
                  </Group>
                </Group>
                <Table striped highlightOnHover withTableBorder withColumnBorders>
                  <Table.Thead>
                    <Table.Tr>
                      <Table.Th><Checkbox checked={rows.length > 0 && rows.every(r => r.selected)} indeterminate={rows.some(r => r.selected) && !rows.every(r => r.selected)} onChange={(e) => toggleAll(e.currentTarget.checked)} /></Table.Th>
                      <Table.Th>Ticket</Table.Th>
                      <Table.Th>Question</Table.Th>
                      <Table.Th>Actions</Table.Th>
                    </Table.Tr>
                  </Table.Thead>
                  <Table.Tbody>
                    {rows.map(row => (
                      <Table.Tr key={row.id}>
                        <Table.Td><Checkbox checked={row.selected} onChange={() => toggleRow(row.id)} /></Table.Td>
                        <Table.Td>{row.ticket ?? '-'}</Table.Td>
                        <Table.Td>{row.relatedQuestion}</Table.Td>
                        <Table.Td>
                          <Group gap="xs">
                            <Button size="xs" variant="light" onClick={() => openEdit(row)}>Edit</Button>
                            <Button size="xs" color="red" variant="light" onClick={() => deleteQuestion(row.id)}>Delete</Button>
                          </Group>
                        </Table.Td>
                      </Table.Tr>
                    ))}
                  </Table.Tbody>
                </Table>
              </Stack>
              <Stack style={{ width: 320 }}>
                <Title order={4}>History</Title>
                <Group align="end">
                  <TextInput label="Date" value={historyDate} onChange={(e) => setHistoryDate(e.currentTarget.value)} />
                  <Select label="Test Id" placeholder="Choose run" data={testId ? [testId] : []} value={historyTestId} onChange={setHistoryTestId} searchable />
                </Group>
                <Button onClick={loadHistory} disabled={!historyTestId}>Load history</Button>
                <Text size="sm" c="dimmed">{runStatus}</Text>
              </Stack>
            </Group>
          </Paper>

          <Paper withBorder p="md">
            <TestRunner running={running} onRunSelected={() => void run(false)} onRunAll={() => void run(true)} />
          </Paper>

          <Paper withBorder p="md">
            <Stack>
              <Title order={4}>Results</Title>
              <ResultsColumn rows={rows} />
            </Stack>
          </Paper>

          <Button variant="light" onClick={() => void loadQuestions(channelId ?? '')}>Refresh questions</Button>
          <QuestionForm opened={formOpen} onClose={closeForm} onSave={saveQuestion} initial={editRow ?? undefined} />
        </Stack>
      </Container>
    </AppShell>
  );
}
