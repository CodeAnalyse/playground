export const API = {
  CHANNEL_LIST: '/channel/list',
  PREDEFINED_QUESTIONS: '/api/predefined-questions',
  TEST_RUNS: '/api/test-runs',
  GENIE_USER_PROMPT: '/Genie/UserPrompt',
  EVALUATION_SIMILARITY: '/Evaluation/SemanticSimilarity'
};
