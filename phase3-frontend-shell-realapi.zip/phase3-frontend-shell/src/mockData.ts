import type { Channel, QuestionRow } from './types';

export const mockChannels: Channel[] = [
  { id: 'OATI', name: 'OATI', dataSource: ['energy_public'], environment: null, envColor: null, type: 'General', isDefault: true },
  { id: 'WEBTAG', name: 'WEBTAG', dataSource: ['websmarttag_20'], environment: 'DEV', envColor: '#228be6', type: 'General', isDefault: false }
];

export const mockQuestions: Record<string, QuestionRow[]> = {
  OATI: [
    { id: '1', ticket: 692365, relatedQuestion: 'When will Source and Sink points be visible?', expectedResponse: 'They are updated periodically.', selected: true, status: 'idle' },
    { id: '2', relatedQuestion: 'How to reset password?', expectedResponse: 'Use the reset flow.', selected: false, status: 'idle' }
  ],
  WEBTAG: [
    { id: '3', ticket: 700101, relatedQuestion: 'What is a Tag?', expectedResponse: 'A tag groups assets.', selected: true, status: 'idle' }
  ]
};
