# Phase 3 Frontend Shell

This frontend shell is completely independent from the .NET projects and can be managed separately.

## What is included
- Vite + React + TypeScript setup
- Mantine UI shell
- Light/Dark theme toggle
- Optional ticket field support
- Mock channel selector, question table, test runner, results table, and history selector
- Sequential live-run simulation and history-load simulation

## How to test before generating the final JS package
1. Install Node.js 18 or later.
2. Open the `phase3-frontend-shell` folder.
3. Run `npm install`.
4. Start the dev server with `npm run dev`.
5. Open the URL shown by Vite.
6. Verify the shell renders the header, channel selector, theme toggle, test id field, question table, history controls, and results panel.
7. Switch between light and dark mode to confirm the theme toggle works.
8. Use **Run selected** and **Run all** to confirm sequential mock updates.
9. Use **Load history** to confirm the loaded-run state.
10. Click **Reset mock data** to restore the initial state.
11. After UI verification, run `npm run build` to generate the final single-file bundle.

## Notes
- The shell remains independent from .NET code.
- History and execution are still mock-driven in the shell; backend wiring can be added later.
- `ticket` is optional in the UI model.
